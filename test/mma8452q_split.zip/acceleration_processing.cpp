#include "acceleration_processing.h"
#include "data_acquisition.h"
#include <math.h>

float getTotalAcceleration()
{
  float x, y, z;
  readMMA8452Q(x, y, z);

  // 3軸合成加速度を計算する
  float totalAccel = sqrt(x * x + y * y + z * z);

  return totalAccel;
}

float getMoveAcceleration()
{
  float totalAccel = getTotalAcceleration();

  // 静止時の重力加速度 1.0g を取り除く
  float moveAccel = totalAccel - 1.0;

  // マイナスになった場合は0として扱う
  if (moveAccel < 0.0)
  {
    moveAccel = 0.0;
  }

  return moveAccel;
}
